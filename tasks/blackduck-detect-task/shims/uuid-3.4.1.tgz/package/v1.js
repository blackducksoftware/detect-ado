'use strict';
const { randomUUID } = require('crypto');
module.exports = function v1() { return randomUUID(); };
