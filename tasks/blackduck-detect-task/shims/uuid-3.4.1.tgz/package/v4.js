'use strict';
const { randomUUID } = require('crypto');
module.exports = function v4() { return randomUUID(); };
