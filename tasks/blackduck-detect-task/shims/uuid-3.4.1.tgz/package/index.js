'use strict';
const { randomUUID } = require('crypto');
const v4 = () => randomUUID();
module.exports = { v4 };
